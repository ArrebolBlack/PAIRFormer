import pandas as pd

def read_fasta(file_path):
    fasta_dict = {}
    with open(file_path, 'r') as file:
        current_name = ""
        current_sequence = ""
        for line in file:
            line = line.strip()
            if line.startswith('>'):
                # 如果是新的fasta条目，保存前一个条目（如果有）
                if current_name:
                    fasta_dict[current_name] = current_sequence
                # 开始新的条目
                current_name = line[1:]  # 去掉'>'
                current_sequence = ""
            else:
                # 拼接序列
                current_sequence += line
        # 添加最后一个条目
        if current_name:
            fasta_dict[current_name] = current_sequence
    return fasta_dict

siRNA_fasta_file = "Dataset_HUVK/siRNA_HUVK.fas"
siRNA_sequences = read_fasta(siRNA_fasta_file)

mRNA_fasta_file = "Dataset_HUVK/mRNA_HUVK.fas"
mRNA_sequence = read_fasta(mRNA_fasta_file)

df_sti = pd.read_csv('Dataset_HUVK/siRNA_mRNA_Efficacy.csv')
df_sti['siRNA_sequence'] = df_sti['siRNA']
df_sti['mRNA_sequence'] = df_sti['mRNA']
df_sti['siRNA_sequence'] = df_sti['siRNA'].map(siRNA_sequences)
df_sti['mRNA_sequence'] = df_sti['mRNA'].map(mRNA_sequence)
df_sti = df_sti[['siRNA', 'siRNA_sequence', 'mRNA', 'mRNA_sequence', 'efficacy']]
df_sti.columns = ['mirna_id', 'mirna_seq', 'mrna_id', 'mrna_seq', 'label']

# 定义拆分规则
chunk_size = 1000  # 每个文件的行数
total_rows = len(df_sti)  # 总行数

# 计算拆分点
split1 = min(chunk_size, total_rows)
split2 = min(2 * chunk_size, total_rows)

# 拆分 DataFrame
df_part1 = df_sti.iloc[:split1]
df_part2 = df_sti.iloc[split1:split2]
df_part3 = df_sti.iloc[split2:]

# 保存为 3 个文件
df_part1.to_csv('Dataset_HUVK/siRNA_mRNA1.txt', index=False, sep='\t')
df_part2.to_csv('Dataset_HUVK/siRNA_mRNA2.txt', index=False, sep='\t')
df_part3.to_csv('Dataset_HUVK/siRNA_mRNA3.txt', index=False, sep='\t')

print(f"文件已拆分保存：")
print(f"- siRNA_mRNA1.txt: {len(df_part1)} 行")
print(f"- siRNA_mRNA2.txt: {len(df_part2)} 行")
print(f"- siRNA_mRNA3.txt: {len(df_part3)} 行")