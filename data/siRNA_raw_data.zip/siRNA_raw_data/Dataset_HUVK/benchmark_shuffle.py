import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score, confusion_matrix, ConfusionMatrixDisplay
import numpy as np

# 读取数据
HUVK = pd.read_csv('Data/Dataset_HUVK/siRNA_mRNA_shuffle.csv', sep='\t')
targetnet = pd.read_csv('Data/Dataset_HUVK/shuffle1_outputs.txt', sep='\t')

# 提取真实标签和预测概率
lst_efficacy = HUVK['efficacy'].to_list()  # 真实标签（0或1）
lst_output = targetnet['output'].to_list()  # 预测概率值
lst_efficacy = lst_efficacy[-len(lst_output):]  # 对齐长度

# 定义阈值范围和存储结果的列表
thresholds = [round(x, 2) for x in np.arange(0.5, 0.96, 0.05)]  # 0.5到0.95，步长0.05
f1_scores = []
precisions = []
recalls = []

# 计算不同阈值下的指标
for thresh in thresholds:
    lst_output_binary = [1 if x > thresh else 0 for x in lst_output]
    f1 = f1_score(lst_efficacy, lst_output_binary)
    precision = precision_score(lst_efficacy, lst_output_binary)
    recall = recall_score(lst_efficacy, lst_output_binary)
    
    f1_scores.append(f1)
    precisions.append(precision)
    recalls.append(recall)
    
    print(f"Threshold: {thresh:.2f} | F1: {f1:.4f} | Precision: {precision:.4f} | Recall: {recall:.4f}")

# 绘制F1-score随阈值变化的折线图
plt.figure(figsize=(10, 6))
plt.plot(thresholds, f1_scores, marker='o', label='F1-score', color='blue')
plt.plot(thresholds, precisions, marker='s', label='Precision', color='green', linestyle='--')
plt.plot(thresholds, recalls, marker='^', label='Recall', color='red', linestyle=':')

# 添加标注和格式
plt.title('Performance Metrics vs Classification Threshold', pad=20)
plt.xlabel('Classification Threshold')
plt.ylabel('Score')
plt.xticks(thresholds)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()

# 标记最高F1-score点
max_f1_idx = np.argmax(f1_scores)
plt.scatter(thresholds[max_f1_idx], f1_scores[max_f1_idx], color='gold', s=200, 
            label=f'Max F1 ({thresholds[max_f1_idx]:.2f}, {f1_scores[max_f1_idx]:.3f})', 
            edgecolors='black', zorder=5)
plt.annotate(f'Max F1: {f1_scores[max_f1_idx]:.3f}', 
             xy=(thresholds[max_f1_idx], f1_scores[max_f1_idx]),
             xytext=(10, 10), textcoords='offset points',
             bbox=dict(boxstyle='round,pad=0.5', fc='yellow', alpha=0.5))

plt.tight_layout()
plt.show()