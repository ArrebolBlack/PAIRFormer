import pandas as pd

def read_fasta(file_path):
    fasta_dict = {}
    with open(file_path, 'r') as file:
        current_name = ""
        current_sequence = ""
        for line in file:
            line = line.strip()
            if line.startswith('>'):
                # 如果是新的fasta条目，保存前一个条目（如果有）
                if current_name:
                    fasta_dict[current_name] = current_sequence
                # 开始新的条目
                current_name = line[1:]  # 去掉'>'
                current_sequence = ""
            else:
                # 拼接序列
                current_sequence += line
        # 添加最后一个条目
        if current_name:
            fasta_dict[current_name] = current_sequence
    return fasta_dict

siRNA_fasta_file = "Simone/mrna_Simone.fas"
siRNA_sequences = read_fasta(siRNA_fasta_file)

mRNA_fasta_file = "Simone/sirna_Simone.fas"
mRNA_sequence = read_fasta(mRNA_fasta_file)

df_sti = pd.read_csv('Simone/Simone_efficacy.csv')
df_sti['siRNA_sequence'] = df_sti['siRNA']
df_sti['mRNA_sequence'] = df_sti['mRNA']
df_sti['siRNA_sequence'] = df_sti['siRNA'].map(siRNA_sequences)
df_sti['mRNA_sequence'] = df_sti['mRNA'].map(mRNA_sequence)
df_sti = df_sti[['siRNA', 'siRNA_sequence', 'mRNA', 'mRNA_sequence', 'efficacy']]
df_sti.columns = ['mirna_id', 'mirna_seq', 'mrna_id', 'mrna_seq', 'label']

df_sti.to_csv('Simone/Simone_siRNA_mRNA_Efficacy.txt', index=False, sep='\t')

print(f"文件已保存：")
print(f"- siRNA_mRNA1.txt: {len(df_sti)} 行")