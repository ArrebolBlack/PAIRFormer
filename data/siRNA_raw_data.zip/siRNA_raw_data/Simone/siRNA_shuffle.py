import pandas as pd
import random

df_sti = pd.read_csv('Simone/Simone_efficacy.csv', sep=',')
df_sti['efficacy'] = 1

lst_siRNA_mRNA = list(zip(df_sti['siRNA'], df_sti['mRNA']))

lst_siRNA = df_sti['siRNA'].to_list()
lst_mRNA = df_sti['mRNA'].to_list()

existing_pairs = set(zip(df_sti['siRNA'], df_sti['mRNA']))

new_rows = []
while len(new_rows) < len(df_sti):
    s = random.choice(lst_siRNA)
    m = random.choice(lst_mRNA)
    if (s, m) not in existing_pairs:
        new_rows.append({'siRNA': s, 'mRNA': m, 'efficacy': 0})
        existing_pairs.add((s, m))  # 避免重复

# 合并到原DataFrame
df_sti_extended = pd.concat(
    [df_sti, pd.DataFrame(new_rows)],
    ignore_index=True
)

df_sti_extended = df_sti_extended.reset_index(drop=True)
df_sti_extended.to_csv('Simone/siRNA_mRNA_Shuffle.csv', sep=',', index=False)